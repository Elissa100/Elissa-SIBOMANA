<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $firstname = $_POST["firstname"];
  $lastname = $_POST["lastname"];
  $email = $_POST["email"];
  $gender = $_POST["gender"];
  $password = $_POST["password"];

  $sql = "INSERT INTO member (firstname, lastname, email, gender, password)
  VALUES ('$firstname', '$lastname', '$email', '$gender', '$password')";

  if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();
}
?>

<!DOCTYPE html>
<html>
<body>

<h2>Create Member</h2>

<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
  First name:<br>
  <input type="text" name="firstname">
  <br>
  Last name:<br>
  <input type="text" name="lastname">
  <br>
  Email:<br>
  <input type="email" name="email">
  <br>
  Gender:<br>
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="female">Female
  <br>
  Password:<br>
  <input type="password" name="password">
  <br><br>
  <input type="submit" value="Submit">
</form> 

</body>
</html>
