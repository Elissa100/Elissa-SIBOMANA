<?php
include 'connection.php';

if(isset($_GET['id'])){
    $id = $_GET['id'];
    
    // SQL query to delete a record
    $sql = "DELETE FROM member WHERE id = '$id'";
    
    // execute the query
    if($conn->query($sql) === TRUE){
        echo "Record deleted successfully";
    } else{
        echo "Error deleting record: " . $conn->error;
    }
    
    // close the database connection
    $conn->close();
} else{
    echo "No ID specified";
}
?>
