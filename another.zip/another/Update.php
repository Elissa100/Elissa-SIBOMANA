<?php
include('connection.php');

if($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve values from form
  $id = $_POST['id'];
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $email = $_POST['email'];
  $gender = $_POST['gender'];
  $password = $_POST['password'];

  // Prepare statement
  $stmt = $conn->prepare("UPDATE member SET firstname = ?, lastname = ?, email = ?, gender = ?, password = ? WHERE id = ?");
  $stmt->bind_param("sssssi", $firstname, $lastname, $email, $gender, $password, $id);

  // Execute statement
  if ($stmt->execute()) {
    echo "Member updated successfully";
  } else {
    echo "Error: " . $stmt->error;
  }

  // Close statement
  $stmt->close();
}

// Close connection
$conn->close();
?>
