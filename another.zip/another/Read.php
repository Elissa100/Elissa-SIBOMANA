<?php
include('connection.php');

// Query for all members
$sql = "SELECT * FROM member";
$result = $conn->query($sql);

// Check if any members exist
if ($result->num_rows > 0) {
  // Display each member's information
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . " - Email: " . $row["email"] . " - Gender: " . $row["gender"] . "<br>";
  }
} else {
  echo "No members found";
}

// Close connection
$conn->close();
?>
